				

		<--- Command to run all programs --->

		gcc -o output *.c $(mysql_config --cflags --libs)
		
		run the executable file
		./output

		password for ADMIN Login : AVENGERS_ASSEMBLE
